<?php
/**
 * Created by PhpStorm.
 * User: Lasith Niroshan
 * Date: 5/27/2015
 * Time: 11:20AM
 */
class Redirect {

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-27
     * @function        to($location)
     * @param           $location - location to redirect
     * @return          void
     * @description     use for redirect to other location
     *
     */
    public static function to($location  = null){
        if($location){
            if(is_numeric($location)){
                switch($location){
                    //page not found
                    case 404:
                        header('HTTP/1.0 404 Not Found');
                        include 'include/errors/404.php';
                        exit();
                        break;
                    /*
                    case 502:

                    break;
                     */
                }
            }
            //call header function with given parameter
            header('Location: ' . $location );
            exit();
        }
    }
}
?>
