<?php
/**
 * Created by PhpStorm.
 * User: Lasith Niroshan
 * Date: 6/02/2015
 * Time: 1:50 PM
 */

class Validate {
    private $_passed = false, //true if pass the validation
        $_errors = array(), //buffer errors
        $_db = null; //buffer db



    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-06-02
     * @function        constructor()
     * @param           -
     * @return          void
     * @description     get database instance for process
     *
     */
    public function __construct(){
        //get db instance
        $this->_db = DB::getInstance();
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-06-02
     * @function        check($source, $items)
     * @param           $source - item for check/ $items - values for checking
     * @return          true or error
     * @description     check field with given status
     *
     */
    public function check($source, $items = array()){
        //run on each item
        foreach($items as $item => $rules ){
            //get item's rule
            foreach($rules as $rule => $rule_value){
                //get value by trimming the source
                $value = trim($source[$item]);
                //get item by escaping the item [escaping -> Convert all HTML entities to their applicable characters]
                $item = escape($item);

                if($rule === 'required' && empty($value)){
                    $this->addError("{$item} is required. "); //add error to $_errors
                } else if(!empty($value)) {
                    switch($rule){
                        //validate for email
                        case 'regexEmail':
                            if(!filter_var($value, FILTER_VALIDATE_EMAIL)){ //use filter.php [standard php class]
                                $this->addError("email address must be valid email address."); //add error to $_errors
                            }
                            break;
                        //validate for name
                        case 'name':
                            if(!empty($value)){ //check name is empty
                                $this->addError("You forgot your user name.");
                            }
                            break;
                        //validate for password
                        case 'regexPassword':
                            if(!preg_match("#[0-9]+#", $value)){                            //for include  0-9
                                $this->addError("password must be valid email address.");
                            } elseif(!preg_match("#[A-Z]+#", $value)){                      //for include A-Z
                                $this->addError("password must be valid email address.");
                            } elseif(!preg_match("#[a-z]+#", $value)){                      //for include a-z
                                $this->addError("password must be valid email address.");
                            }  elseif(!preg_match("/[!@#$%^&*()\-_=+{};:,<.>]/", $value)){  //for include special character
                                $this->addError("password must be valid email address.");
                            }
                            break;
                        //validate for registration number
                        case 'regexRegistrationNumber':
                            if(!preg_match('([0-9]{4}.*[a-zA-Z]{2}.*[0-9]{3})',$value)){
                                $this->addError("Your registration number is wrong.");
                            }
                            break;
                        //validate sor string -> no numbers
                        case 'regexString':
                            if(!preg_match("/^[a-zA-Z]*$/", $value)){
                                $this->addError("{$item} must be valid {$item}.");
                            }
                            break;
                        //validate for number -> no letters
                        case 'regexInt':
                            if(!preg_match("/^[0-9]*$/", $value)){
                                $this->addError("{$item} must be valid {$item}.");
                            }
                            break;
                        //validate NIC -> 923342699V/v/X/x
                        case 'regexNic':
                            if(!preg_match('/^[0-9]{9}[vVxX]$/',$value)){
                                $this->addError("Your NIC number is wrong.");
                            }
                            break;
                        //validate phone number
                        case 'regexPhone':
                            if(!preg_match("#[0-9]+#", $value)){
                                $this->addError("{$item} must be valid phone number.");
                            }
                            break;
                        //check for min value
                        case 'min':
                            if(strlen($value) < $rule_value){
                                $this->addError("{$item} must be a minimum of {$rule_value} characters.");
                            }
                            break;
                        //check for max value
                        case 'max':
                            if(strlen($value) > $rule_value){
                                $this->addError("{$item} must be a maximum of {$rule_value} characters.");
                            }
                            break;
                        //check given data is match with other given item
                        case 'matches':
                            if($value != $source[$rule_value]){
                                $this->addError("{$rule_value} must match {$item}");
                            }
                            break;
                        //check for uniqueness
                        case 'unique':
                            $check = $this->_db->get($rule_value,array($item, '=', $value));
                            if($check->count()){
                                $this->addError("{$item} already exist ");
                            }
                            break;
                    }
                }
            }
        }
        if(empty($this->_errors)){
            $this->_passed = true;
        }
        return $this;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-06-02
     * @function        addError($error)
     * @param           $error - give an error
     * @return          void
     * @description     add errors to $_errors and store it
     *
     */
    private function addError($error){
        $this->_errors[] = $error;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-06-02
     * @function        errors()
     * @param           -
     * @return          error object
     * @description     return error
     *
     */
    public function errors(){
        return $this->_errors;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-06-02
     * @function        passed()
     * @param           -
     * @return          boolean
     * @description     check for validation pass or not
     *
     */
    public function passed(){
        return $this->_passed;
    }
}
?>
