<?php
/**
 * Created by PhpStorm.
 * User: Lasith Niroshan
 * Date: 5/23/2015
 * Time: 1:45 PM
 */
//set configurations for all
class Config{

     /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-23
     * @function        get($path)
     * @param           $path - path to config array
     * @return          $config array or false
     * @description     this function will return configurations for other php files
     *
     */
    public static function get($path = null){
        if($path){
            $config = $GLOBALS['config'];
            $path = explode('/', $path);

            foreach($path as $bit){
                 if(isset($config[$bit])){
                     $config = $config[$bit];
                 }
            }
//            print_r($path);
            return $config;
        }
        return false;
    }
}
?>