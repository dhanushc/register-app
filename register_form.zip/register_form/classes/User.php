<?php
/**
 * Created by PhpStorm.
 * User: Lasith Niroshan
 * Date: 06/01/2015
 * Time: 2:10AM
 */


class user{
    private $_db, //db buffer
            $_data, //data buffer
            $_sessionName, //for session name
            $_cookieName, //for cookie name
            $_isLoggedIn; //check for logged in or not


    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-06-01
     * @function        constructor($user)
     * @param           $user - user object
     * @return          make a user object by getting details from db
     * @description     this function make a user object and assigning data to it
     *
     */
    public function __construct($user = null) {
        $this->_db = DB::getInstance();
        $this->_sessionName = Config::get('session/session_name');
        $this->_cookieName = Config::get('remember/cookie_name');

        if(!$user){
            if(Session::exists($this->_sessionName)){
                $user = Session::get($this->_sessionName);
                if($this->find($user)){
                    $this->_isLoggedIn = true;
                } else {
                    //process logout
                }
            }
        } else {
            $this->find($user);
        }

    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-06-01
     * @function        update($fields, $id)
     * @param           $fields - fields for updating/ $id - userID
     * @return          void
     * @description     update user details for given userID
     *
     */
    public function update($fields = array(), $id=null){
        //for admin (can update any user details)
        if(!$id && $this->isLoggedIn()){
            //get userID from users table
            $id = $this->data()->id;
        }
        //run update function
        if(!$this->_db->update('users', $id, $fields)) {
            //if error return error
            throw new Exception('There was a problem updating..');
        }
    }


    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-06-01
     * @function        create($fields)
     * @param           $fields - fields for inserting
     * @return          void
     * @description     insert user data to users table
     *
     */
    public function create($fields = array()) {
        //call insert function to insert
        if(!$this->_db->insert('users', $fields)){
            //throw an exception
            throw new Exception('There was a problem creating an account.');
        }
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-06-01
     * @function        find($user)
     * @param           $user - user object
     * @return          void
     * @description     find user is exists or not in database
     *
     */
    public function find($user = null){
        if($user){
            //get input and check it is id or username
            $field = (is_numeric($user)) ? 'id' : 'username';
            //buffer data from database for user object
            $data = $this->_db->get('users', array($field, '=', $user));
            //get count
            if($data->count()){
                //if one or more record exists
                $this->_data = $data->first();
                return true;
            }
        }
        return false;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-06-01
     * @function        login($username, $password, $remember)
     * @param           $username - username of the user/ $password - password of the user/ $remember -remember user flag
     * @return          void
     * @description     user log to the system + make session + make cookie
     *
     */
    public function login($username=null, $password=null, $remember = false){
        if(!$username && !$password && $this->exists()) {
            //log user in
            Session::put($this->_sessionName, $this->data()->id);
        }else {
            //create user object
            $user = $this->find($username);
//            echo $username;
//            === is identical
            if ($user) {
                //hash the password and check it with db password
                if ($this->data()->password === Hash::make($password)) {
                    //create a session and put it to session array
                    Session::put($this->_sessionName, $this->data()->id);

//                    echo Hash::make($password);
                    /*
                     * If user ticked a "remember me" the execute this process
                     */
                    if ($remember) {
                        $hash = Hash::unique(); //make unique id to user
                        //check this user exist on users_session table
                        $hashCheck = $this->_db->get('users_session', array('user_id', '=', $this->data()->id));
                        //if not found a session for this user
                        if (!$hashCheck->count()) {
                            //insert new data to table
                            $this->_db->insert('users_session', array(
                                'user_id' => $this->data()->id,
                                'hash' => $hash
                            ));
                        } else {
                            //get db data entry
                            $hash = $hashCheck->first()->hash;
                        }
                        //create cookie for that user
                        Cookie::put($this->_cookieName, $hash, Config::get('remember/cookie_expiry'));
                    }
                    //login success
                    return true;
                }
            }
        }
        //login fail
        return false;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-06-01
     * @function        hasPermission($key)
     * @param           $key - key for check user permission (this include in json object)
     * @return          boolean
     * @description     this function use to make sure user in what user level [standard user, admin, coordinator]
     *
     */
    public function hasPermission($key){
        //get user group from db using get function
        $group = $this->_db->get('groups', array('id', '=', $this->data()->group));
//        print_r($group->first());
        //if group exists
        if($group->count()){
            //get permissions by decoding json object
            $permissions = json_decode($group->first()->permissions, true);
            //check permission
            if($permissions[$key] == true){
                return true;
            }
        }
        return false;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-06-01
     * @function        exists()
     * @param           -
     * @return          boolean
     * @description     this function checks given data is exists or not
     *
     */
    public function exists(){
        return (!empty($this->_data)) ? true : false;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-06-01
     * @function        logout()
     * @param           -
     * @return          void
     * @description     logout process
     *
     */
    public function logout(){
        //delete user session
        $this->_db->delete('users_session', array('user_id', '=', $this->data()->id));
        Session::delete($this->_sessionName);
        //delete cookie
        Cookie::delete($this->_cookieName);
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-06-01
     * @function        data()
     * @param           -
     * @return          return all data
     * @description     to ge data of user object
     *
     */
    public  function data(){
        return $this->_data;
    }


    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-06-01
     * @function        isLoggedIn()
     * @param           -
     * @return          void
     * @description     checks user is logged in or not
     *
     */
    public function isLoggedIn(){
        return $this->_isLoggedIn;
    }

//    public function loadDropBoxData($table, $field){
//        $this->_db->loadDropBox($table, $field);
//    }
}

?>