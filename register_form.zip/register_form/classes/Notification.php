<?php
/**
 * Created by PhpStorm.
 * User: lasith-niro
 * Date: 17/10/15
 * Time: 11:37
 */

class Notification {
    private $_Ndb, //db buffer
        $_Ndata; //data buffer


    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-10-17
     * @function        constructor($Notification)
     * @param           $Notification - notification object
     * @return          database instance for notification object
     * @description     get database instance for notifications
     *
     */
    public function __construct($Notification = null){
        $this->_Ndb = DB::getInstance();
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-10-17
     * @function        createNotification($fields)
     * @param           $fields - keys and values for insert
     * @return          void
     * @description     insert data to notification table
     *
     */
    public function createNotification($fields = array()) {
        if(!$this->_Ndb->insert('notification', $fields)){
            throw new Exception('There was a problem in connection');
        }
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-10-17
     * @function        deleteNotification($id)
     * @param           $id - id for search row
     * @return          void
     * @description     delete data row from notification table
     *
     */
    public function deleteNotification($id){
        if(!$this->_Ndb->delete('notification', array('nID', '=', $id))){
            throw new Exception('There was a problem in connection');
        }
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-10-17
     * @function        disAllowUser($userID, $notifyID)
     * @param           $userID - user id provide by system/ $notifyID - notification id provide by system
     * @return          void
     * @description     delete data row from user_notification table (disallow user)
     *
     */
    public function disAllowUser($userID, $notifyID){
        if(!$this->_Ndb->query('DELETE FROM user_notification WHERE nID = ? AND uID = ?',array($notifyID,$userID))){
            throw new Exception('There was a problem in connection');
        }

    }

    /*
     * @author          Lasith Niroshan
     * @version         2.0
     * @created         2015-12-20
     * @function        getRepeatStudent()
     * @param           -
     * @return          get repeat students index number from educationdept_db
     * @description     This function use to get all repeat student's indexes for calculations
     *
     */
    public function getRepeatStudent(){
        //sql query
        $sqlLine = "SELECT index_no FROM results WHERE repeat_status = 1 GROUP BY index_no";
        $data = $this->_Ndb->query2($sqlLine)->results();
        return $data;
    }

    /*
     * @author          Lasith Niroshan
     * @version         2.0
     * @created         2015-12-20
     * @function        getBatch($year)
     * @param           $year - the year for get ids
     * @return          All user ids of student's  for given year
     * @description     When we want first year all student's userIDs , then we can use this
     *
     */
    public function getBatch($year){
        //get ids from database
        $data = $this->_Ndb->getID('users', array('year' , '=' , $year))->results();
        return $data;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-10-17
     * @function        getUserID($index)
     * @param           $index - user's UCSC index number
     * @return          user id of given index number
     * @description     When we want student's userIDs , then we can use this
     *
     */
    public function getUserID($index){
        return $this->_Ndb->getID('users',array('indexNumber' , '=' , $index))->results();

    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-10-17
     * @function        getUsername($id)
     * @param           $id - user's user id
     * @return          username of given userID
     * @description     When we want student's username , then we can use this
     *
     */
    public function getUsername($id){
        $sql = "SELECT username FROM users WHERE id = $id";
        $data = $this->_Ndb->query($sql)->results();
        return $data;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-10-17
     * @function        getUserBatch($id)
     * @param           $id - user's user id
     * @return          user's batch(year) of given userID
     * @description     this function return user's batch when we give userID as a parameter
     *
     */
    public function getUserBatch($id){
        $sql = "SELECT year FROM users WHERE id = $id";
        $data = $this->_Ndb->query($sql)->results();
        return $data;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-10-17
     * @function        getTopic($notifid)
     * @param           $notifid - notification id
     * @return          topic of notification for relevant notification ID
     * @description     this function return topic of notification when we give notificationID as a parameter
     *
     */
    public function getTopic($notifyid){
        $sql = "SELECT topic FROM notification WHERE nID = $notifyid";
        $data = $this->_Ndb->query($sql)->results();
        return $data;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-10-17
     * @function        assignBatch($fields)
     * @param           $fields - usersIDs and notificationIDs store in a associative array
     * @return          void
     * @description     insert data to user_notification table
     *
     */
    public function assignBatch($fields=array()){
        if(!$this->_Ndb->insert('user_notification', $fields)){
            //throw new Exception('There was a problem in connection');
            //print_r($fields);

            //extract userID
            $x = $fields['uID'];
            //make a temporary user object
            $tmpUser = new User();
            //assign data to created temporary user
            $tmpUser->find($x);
            //print an error
            echo "<div class='alert alert-danger'>This notification has been already send to " . $tmpUser->data()->username . "</div>";
        }
    }

    /*
     * @author          Lasith Niroshan
     * @version         2.0
     * @created         2015-10-17
     * @function        insertUN($fields)
     * @param           $fields - usersIDs and notificationIDs store in a associative array
     * @return          void
     * @description     insert data to user_notification table. This function is an improvement of assignBatch() function
     *
     */
    //insertUN = insertUserNotification
    public function insertUN($fields){
        if(!$this->_Ndb->insert('user_notification', $fields)){
            //throw new Exception('There was a problem sending a notification.');
            $userID = $fields['uID'];
            $tmpUser = new User();
            $tmpUser->find($userID);
            //send error notification to user interface
            echo "<div class='alert alert-danger alert-dismissible'>This notification has been already send to " . $tmpUser->data()->username . "<button type = 'button' class = 'close' data-dismiss = 'alert' aria-hidden = 'true'>
      &times;
   </button></div>";
        } else {
            $userID = $fields['uID'];
            $tmpUser = new User();
            $tmpUser->find($userID);
            //send success notification to user interface
            echo "<div class='alert alert-success alert-dismissible'>This notification was send successfully to " . $tmpUser->data()->username . "<button type = 'button' class = 'close' data-dismiss = 'alert' aria-hidden = 'true'>
      &times;
   </button></div>";
        }
    }

    /*
     * @author          Lasith Niroshan
     * @version         2.0
     * @created         2015-10-17
     * @function        find($notification)
     * @param           $notification - notification object
     * @return          boolean
     * @description     When function find a notification for given data it will return true otherwise false
     *
     */
    public function find($notification = null){
        if($notification){
            $field = (is_numeric($notification)) ? 'nID' : 'topic';
//            $data = $this->_db->get('users', array($field, '=', $user));
            $data = $this->_Ndb->get('notification', array($field, '=', $notification));

            if($data->count()){
                //get first item
                $this->_Ndata = $data->first();
                return true;
            }
        }
        return false;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-10-17
     * @function        outNotifications($nID)
     * @param           $nID - notification id
     * @return          return all notifications allocated to given notification ID (as an array)
     * @description     Using this function we can get all details for given notificationID
     *
     */
    public function outNotifications($nID){
        return $this->_Ndb->get('user_notification',array('nID','=',$nID))->results();

    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-10-17
     * @function        printNotification($notificationID)
     * @param           $notificationID - notification id
     * @return          notification object for given notificationID
     * @description     use for get topic and content of the notification for given notificationID
     *
     */
    public function printNotification($notificationID){
        return $this->_Ndb->get('notification', array('nID','=',$notificationID))->results();
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-10-17
     * @function        getData()
     * @param           -
     * @return          notification objects
     * @description     use for get topic and content of the all notification
     *
     */
    public function getData(){
        return $this->_Ndb->getAll('SELECT *', 'notification', 'nID');
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-10-17
     * @function        data()
     * @param           -
     * @return          data of the object
     * @description     return all data for the
     *
     */
    public function data(){
        return $this->_Ndata;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-10-17
     * @function        getNotificationID()
     * @param           -
     * @return          return notification ID of the notification object
     * @description     return notificationID
     *
     */
    public function getNotificationID(){
        return $this->_Ndata->nID;
    }
}
?>