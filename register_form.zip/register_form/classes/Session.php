<?php
/**
 * Created by PhpStorm.
 * User: Lasith Niroshan
 * Date: 5/23/2015
 * Time: 1:49 PM
 */
class Session{
    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-27
     * @function        exists($name)
     * @param           $name - session name
     * @return          boolean
     * @description     find given session exists or not
     *
     */
    public static function exists($name){
//        isset — Determine if a variable is set and is not NULL
        return (isset($_SESSION[$name])) ? true : false;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-27
     * @function        put($name, $value)
     * @param           $name - session name / $value - session value
     * @return          void
     * @description     put session name and session value to session array
     *
     */
    public static function put($name, $value){
        return $_SESSION[$name] = $value;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-27
     * @function        get($name)
     * @param           $name - session name
     * @return          data about given session name
     * @description     use to get session details for given session name
     *
     */
    public static function get($name){
        return $_SESSION[$name];
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-27
     * @function        delete($name)
     * @param           $name - session name
     * @return          void
     * @description     delete session of given name
     *
     */
    public static function delete($name){
        if(self::exists($name)){
            //call unset function and delete session data
            unset($_SESSION[$name]);
        }
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-27
     * @function        flash($name, $string)
     * @param           $name - session name / $string - value for
     * @return          void
     * @description     when given session is exists then delete it else put it to session array
     *
     */
    public static function flash($name, $string = null){
        if(self::exists($name)){
            $session = self::get($name);
            self::delete($name);
            return $session;
        } else {
            self::put($name, $string);
        }
    }
}

?>