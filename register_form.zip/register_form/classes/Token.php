<?php
/**
 * Created by PhpStorm.
 * User: Lasith Niroshan
 * Date: 5/23/2015
 * Time: 1:49 PM
 */

class Token{

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-27
     * @function        generate()
     * @param           -
     * @return          void
     * @description     create a token for session and put it to config array
     *
     */
    public static function generate(){
        return Session::put(Config::get('session/token_name'), md5(uniqid()));
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-27
     * @function        check($token)
     * @param           $token - unique id of the token
     * @return          boolean
     * @description     check the given token exists or not.
     *
     */
    public static function check($token) {
        //get token name by config array
        $tokenName = Config::get('session/token_name');

        if(Session::exists($tokenName) && $token === Session::get($tokenName)){
            Session::delete($tokenName); //delete session
            return true;
        }
        return false;
    }
}

?>