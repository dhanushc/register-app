<?php
/**
 * Created by PhpStorm.
 * User: Lasith Niroshan
 * Date: 5/28/2015
 * Time: 1:46 PM
 */

class DB{
    private static $_instance = null; //for db instance
    private $_pdo_easypay, //pdo object for easypay_db
        $_pdo_academic, //pdo object for educationdept_db
        $_query, //for query object
        $_error = false,
        $_results,
        $_count = 0;
    /*
     * @author          Lasith Niroshan
     * @version         2.0
     * @created         2015-05-28
     * @modified        2015-12-20
     * @function        constructor
     * @param           -
     * @return          void
     * @description     connect with database
     *
     */
    private function __construct() {
        try {
            $this->_pdo_easypay = new PDO('mysql:host=' . Config::get('mysql/host') . ';dbname=' . Config::get('mysql/db'), Config::get('mysql/username'), Config::get('mysql/password'));
            $this->_pdo_academic = new PDO('mysql:host=' . Config::get('mysql/host') . ';dbname=' . Config::get('mysql/db2'), Config::get('mysql/username'), Config::get('mysql/password'));
//            echo "connected";
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }
    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-28
     * @function        getInstance()
     * @param           -
     * @return          void
     * @description     get DB object (DB class object)
     *
     */
    public static function getInstance() {
        if (!isset(self::$_instance)) {
            self::$_instance = new DB();
        }
        return self::$_instance;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-28
     * @function        query($sql, $param)
     * @param           -
     * @return          result set
     * @description     Run query for given parameters
     *
     */
    public function query($sql, $parms = array()){
        $this->_error = false;
        if ($this->_query = $this->_pdo_easypay->prepare($sql)) {
            $x = 1;
            if (count($parms)) {
                foreach ($parms as $param) {
                    $this->_query->bindValue($x, $param);
                    $x++;
                }
            }
            if ($this->_query->execute()) {
                $this->_results = $this->_query->fetchAll(PDO::FETCH_OBJ);
                $this->_count = $this->_query->rowCount();
            } else {
                $this->_error = true;
            }
        }
        return $this;
    }

    /*
     * @author          Lasith Niroshan
     * @version         2.0
     * @created         2015-12-20
     * @function        query2($sql, $param)
     * @param           -
     * @return          result set
     * @description     Run query for given parameters connect with educationaldept_db
     *
     */
    //$_pdo_academic
    public function query2($sql, $parms = array()){
        $this->_error = false;
        if ($this->_query = $this->_pdo_academic->prepare($sql)) {
            $x = 1;
            if (count($parms)) {
                foreach ($parms as $param) {
                    $this->_query->bindValue($x, $param);
                    $x++;
                }
            }
            if ($this->_query->execute()) {
                $this->_results = $this->_query->fetchAll(PDO::FETCH_OBJ);
                $this->_count = $this->_query->rowCount();
            } else {
                $this->_error = true;
            }
        }
        return $this;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-23
     * @function        getLast($table, $where)
     * @param           $table - db table name / $where - where clause
     * @return          return all data in the given table
     * @description     using getAll function this give all data from given table
     *
     */
    public function getLast($table, $where) {
        return $this->getAll('SELECT *', $table, $where);
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-23
     * @function        getAll($action, $table, $where)
     * @param           $action - query action /$table - db table name / $where - where clause
     * @return          return results for given parameters in easypay_db
     * @description     Provide ability to run given database action in easypay_db
     *
     */
    public function getAll($action, $table, $value){
        $sql = "{$action} FROM {$table} ";

        if(!$this->query($sql, array($value))->error()){
            return $this;
        }
        return false;
    }

    /*
     * @author          Lasith Niroshan
     * @version         2.0
     * @created         2015-12-23
     * @function        getAll2($action, $table, $where)
     * @param           $action - query action /$table - db table name / $where - where clause
     * @return          return results for given parameters in educationdept_db
     * @description     Make ability to run given database action in educationdept_db
     *
     */
    public function getAll2($action, $table, $value){
        $sql = "{$action} FROM {$table} ";

        if(!$this->query2($sql, array($value))->error()){
            return $this;
        }
        return false;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-23
     * @function        action($action, $table, $where)
     * @param           $action - query action /$table - db table name / $where - where clause
     * @return          return results for given parameters in easypay_db
     * @description     Provide ability to run given database action in easypay_db
     *
     */
    public function action($action, $table, $where = array()) {
        //where = (db_column, operator , value)
        if (count($where) === 3) {
            //operators array
            $operators = array('=', '>', '<', '>=', '<=', 'LIKE', 'NOT LIKE');
            //extract fields from input
            $field      = $where[0];
            $operator   = $where[1];
            $value      = $where[2];
            //get parameters to work
            if (in_array($operator, $operators)) {
                //make sql statement
                $sql = "{$action} FROM {$table} WHERE {$field} {$operator} ? ";
                //run the query and buffer the results
                if (!$this->query($sql, array($value))->error()) {
                    return $this;
                }
            }
        }
        return false;
    }

    /*
     * @author          Lasith Niroshan
     * @version         2.0
     * @created         2015-12-23
     * @function        action2($action, $table, $where)
     * @param           $action - query action /$table - db table name / $where - where clause
     * @return          return results for given parameters in educationdept_db
     * @description     Provide ability to run given database action in educationdept_db
     *
     */
    //same function to action($action, $table, $where = array())
    public function action2($action, $table, $where = array()) {
        if (count($where) === 3) {
            $operators = array('=', '>', '<', '>=', '<=', 'LIKE', 'NOT LIKE');

            $field      = $where[0];
            $operator   = $where[1];
            $value      = $where[2];

            if (in_array($operator, $operators)) {
                $sql = "{$action} FROM {$table} WHERE {$field} {$operator} ? ";

                if (!$this->query2($sql, array($value))->error()) {
                    return $this;
                }
            }
        }
        return false;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-23
     * @function        getID($table, $where)
     * @param           $table - db table name / $where - where clause
     * @return          return ids(db column name is 'id') for given parameters in easypay_db
     * @description     When we want to get ids from database
     *
     */
    public function getID( $table, $where)
    {
        return $this->action('SELECT id', $table, $where);
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-23
     * @function        get($table, $where)
     * @param           $table - db table name / $where - where clause
     * @return          return ids(db column name is 'id') for given parameters in easypay_db
     * @description     run 'SELECT * FROM $table WHERE $where' query and give results
     *
     */
    public function get($table, $where)
    {
        //use action function
        return $this->action('SELECT * ', $table, $where);
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-24
     * @function        delete($table, $where)
     * @param           $table - db table name / $where - where clause
     * @return          delete given data raw for given parameters in easypay_db
     * @description     run 'DELETE FROM $table WHERE $where' query and delete raw
     *
     */
    public function  delete($table, $where)
    {
        //use action function
        return $this->action('DELETE ', $table, $where);
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-24
     * @function        insert($table, $fields)
     * @param           $table - db table name / $fields - db keys and values
     * @return          insert given data to table in easypay_db for relevant keys
     * @description     Provide ability to insert data
     *
     */
    public function insert($table, $fields = array()) {
        //extract db keys
        $keys = array_keys($fields);
        $values = '';
        $x = 1;
        //get values
        foreach ($fields as $field) {
            $values .= '?';
            if ($x < count($fields)) {
                $values .= ', ';
            }
            $x++;
        }
//        $sql1 = INSERT INTO `lr`.`users` (`id`, `username`, `password`, `salt`, `name`, `joined`, `group`) VALUES ('1', 'lasith', 'lasith123', 'salt', 'lasith niroshan', '2015-06-23 08:13:25', '1');
        //make sql query
        $sql = "INSERT INTO {$table} (`" . implode('`, `', $keys) . "`) VALUES ({$values})";
        //run sql query
        if (!$this->query($sql, $fields)->error()) {
            return true;
        }
        return false;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-24
     * @function        update($table, $id, $fields)
     * @param           $table - db table name / $id - unique column name / $fields - db keys and values
     * @return          update data row for given id in easypay_db
     * @description     Provide ability to update data
     *
     */
    public function update($table, $id,  $fields){
        $set = '';
        $x = 1;
        //filter keys
        foreach($fields as $name => $value){
            $set .= "{$name} = ?";
            if($x < count($fields)){
                $set .= ', ';
            }
            $x++;
        }
        //sql statement
        $sql = "UPDATE {$table} SET {$set} WHERE id = {$id}";
        //runs the query
        if(!$this->query($sql, $fields)->error()) {
            return true;
        }
        return false;
    }

    /*
     * @author          Lasith Niroshan
     * @version         2.0
     * @created         2015-12-23
     * @function        getID2($table, $where)
     * @param           $table - db table name / $where - where clause
     * @return          return ids(db column name is 'id') for given parameters in educationdept_db
     * @description     When we want to get ids from database
     *
     */
    //same function to getID( $table, $where )
    public function getID2( $table, $where)
    {
        return $this->action2('SELECT id', $table, $where);
    }

    /*
     * @author          Lasith Niroshan
     * @version         2.0
     * @created         2015-12-23
     * @function        get2($table, $where)
     * @param           $table - db table name / $where - where clause
     * @return          return ids(db column name is 'id') for given parameters in educationdept_db
     * @description     When we want to get ids from database
     *
     */
    public function get2($table, $where)
    {
        return $this->action2('SELECT * ', $table, $where);
    }

    /*
     * @author          Lasith Niroshan
     * @version         2.0
     * @created         2015-12-23
     * @function        delete2($table, $where)
     * @param           $table - db table name / $where - where clause
     * @return          delete given data raw for given parameters in educationdept_db
     * @description     run 'DELETE FROM $table WHERE $where' query and delete raw
     *
     */
    //same function for delete
    public function  delete2($table, $where)
    {
        return $this->action2('DELETE ', $table, $where);
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-24
     * @function        insert($table, $fields)
     * @param           $table - db table name / $fields - db keys and values
     * @return          insert given data to table in educationdept_db for relevant keys
     * @description     Provide ability to insert data
     *
     */
    //same function insert funcion
    public function insert2($table, $fields = array()) {
        $keys = array_keys($fields);
        $values = '';
        $x = 1;

        foreach ($fields as $field) {
            $values .= '?';
            if ($x < count($fields)) {
                $values .= ', ';
            }
            $x++;
        }
//        $sql1 = INSERT INTO `lr`.`users` (`id`, `username`, `password`, `salt`, `name`, `joined`, `group`) VALUES ('1', 'lasith', 'lasith123', 'salt', 'lasith niroshan', '2015-06-23 08:13:25', '1');
        $sql = "INSERT INTO {$table} (`" . implode('`, `', $keys) . "`) VALUES ({$values})";
        if (!$this->query2($sql, $fields)->error()) {
            return true;
        }
        return false;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-24
     * @function        update($table, $id, $fields)
     * @param           $table - db table name / $id - unique column name / $fields - db keys and values
     * @return          update data row for given id in educationdept_db
     * @description     Provide ability to update data
     *
     */
    //same function update
    public function update2($table, $id,  $fields){
        $set = '';
        $x = 1;

        foreach($fields as $name => $value){
            $set .= "{$name} = ?";
            if($x < count($fields)){
                $set .= ', ';
            }
            $x++;
        }
        $sql = "UPDATE {$table} SET {$set} WHERE id = {$id}";

        if(!$this->query2($sql, $fields)->error()) {
            return true;
        }
        return false;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-24
     * @function        results()
     * @param           -
     * @return          result object
     * @description     Provide ability to return data
     *
     */
    public function results(){
        return $this->_results;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-24
     * @function        first()
     * @param           -
     * @return          returns first data in result object
     * @description     Provide ability to return data
     *
     */
    public function first(){
        return $this->results()[0];
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-24
     * @function        error()
     * @param           -
     * @return          returns errors
     * @description     Provide ability to return errors
     *
     */
    public function error(){
        return $this->_error;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-24
     * @function        count()
     * @param           -
     * @return          returns count of data set
     * @description     Provide ability to return count
     *
     */
    public  function count(){
        return $this->_count;
    }


}

?>