<?php
/**
 * Created by PhpStorm.
 * User: Lasith Niroshan
 * Date: 5/23/2015
 * Time: 1:47 PM
 */
class Input{

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-24
     * @function        exists($type)
     * @param           $type - get data from POST or GET method
     * @return          value of given parameter
     * @description     Provide ability return value
     *
     */
    public static function exists($type = 'post') {
        switch ($type) {
            case 'post':
                return (!empty($_POST)) ? true : false;
                break;
            case 'get':
                return (!empty($_GET)) ? true : false;
                break;
            default:
                return false;
                break;
        }
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-24
     * @function        get($item)
     * @param           $item - input data
     * @return          returns value we inputed
     * @description     Provide ability return data
     *
     */
    public static function  get($item){
        if(isset($_POST[$item])){
            return $_POST[$item];
        } else if (isset($_GET[$item])){
            return $_GET[$item];
        }
        return '';
    }
}

?>