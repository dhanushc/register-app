<?php
/**
 * Created by PhpStorm.
 * User: lasith-niro
 * Date: 12/08/15
 * Time: 08:45
 */
//we don't use this class
class keygen {

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-08-12
     * @function        constructor($string, $number)
     * @param           $string - string for make a key / $number - number to bind with string
     * @return          string which is bind string with key
     * @description     Provide ability make keys
     *
     */
    public function __construct($string, $number){
        $str=$string . $number;
        return $str;
    }
} 