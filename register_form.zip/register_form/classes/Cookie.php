<?php
/**
 * Created by PhpStorm.
 * User: Lasith Niroshan
 * Date: 5/23/2015
 * Time: 1:45 PM
 */

class Cookie {
    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-28
     * @function        exists($name)
     * @param           $name - cookie name
     * @return          true or false
     * @description     this function checks given cookie is exists or not
     *
     */
    public static function exists($name){
        return (isset($_COOKIE[$name]) ? true : false);
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-28
     * @function        get($name)
     * @param           $name - cookie name
     * @return          true or false
     * @description     this function checks given cookie is exists or not
     *
     */
    public static function get($name){
        return $_COOKIE[$name];
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-28
     * @function        put($name,$value, $expiry)
     * @param           $name - cookie name / $value - cookie value / $expiry - cookie expire time
     * @return          true or false
     * @description     this function set the cookie to given value and expire time
     *
     */
    public static function put($name, $value, $expiry) {
        if(setcookie($name, $value, time() + $expiry, '/')) {
            return true;
        }
        return false;
    }

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-28
     * @function        delete($name)
     * @param           $name - cookie name
     * @return          void
     * @description     this function delete the cookie
     *
     */

    public static function delete($name){
        self::put($name, '', time() - 1);
    }
}
?>