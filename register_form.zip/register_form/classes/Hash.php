<?php
/**
 * Created by PhpStorm.
 * User: Lasith Niroshan
 * Date: 5/24/2015
 * Time: 2:46 AM
 */
class Hash{

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-24
     * @function        make($string, $salt)
     * @param           $string - value to hash / $salt - salting string for hash
     * @return          returns hash string
     * @description     Provide ability hash any string
     *
     */
    public static function make($string, $salt = ''){
        //use sha256 method for hash => make 64 bit string
        return hash('sha256', $string . $salt );
    }
    /*
    public static function  salt($length){
        return mcrypt_create_iv($length);
    }
    */

    /*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-05-24
     * @function        unique()
     * @param           -
     * @return          void
     * @description     Provide ability make unique id
     *
     */
    public static function unique(){
        return self::make(uniqid());
    }
}