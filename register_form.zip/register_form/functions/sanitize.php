<?php
/**
 * Created by PhpStorm.
 * User: Lasith Niroshan
 * Date: 5/23/2015
 * Time: 1:53 PM
 */

/*
     * @author          Lasith Niroshan
     * @version         1.0
     * @created         2015-06-02
     * @function        escape($string)
     * @param           $string - string for convert
     * @return          return processed string
     * @description     this function convert all HTML entities to their applicable characters
     *
     */
function escape($string){
    //htmlentities -> Convert all HTML entities to their applicable characters
    return htmlentities($string, ENT_QUOTES, 'UTF-8');
}

?>